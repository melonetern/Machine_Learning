function zeichneStreudiagramm(x1, x2, y)
%zeichneStreudiagramm zeichnet ein Streudiagramm der Daten in x1, x2 und y 

%Suchen der Indizes f�r die Einsen und Nullen
Einsen = find(y == 1); 
Nullen = find(y == 0);

% Plot Examples
plot(x1(Einsen), x2(Einsen), 'g+','LineWidth', 1.2);
hold on
plot(x1(Nullen), x2(Nullen), 'ro', 'LineWidth', 1.2);
hold off







% =========================================================================



hold off;

end
