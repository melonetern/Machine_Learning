%Initialisierung
n=2;
initial_beta = zeros(n+1,1);

%  Setzen von Optionen fuer fminunc
options = optimset('GradObj', 'on', 'MaxIter', 400);

%  Ausfuehren von fminunc um den Optimalwert fuer beta zu erhalten
[beta, cost] = ...
	fminunc(@(t)(Kostenfunktion(t, X, y)), initial_beta, options);
