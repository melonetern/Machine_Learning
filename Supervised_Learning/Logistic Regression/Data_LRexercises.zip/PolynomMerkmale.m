function out = PolynomMerkmale(x1, x2, Grad)
% Polynommerkmale erzeugt aus den Originalmerkmalen x1 und x2
% abgeleitete Polynommerkmale bis zum vorgegebenen Grad

out = ones(size(x1(:,1)));
for i = 1:Grad
    for j = 0:i
        out(:, end+1) = (x1.^(i-j)).*(x2.^j);
    end
end

end