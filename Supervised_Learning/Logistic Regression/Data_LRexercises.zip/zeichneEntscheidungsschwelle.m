function zeichneEntscheidungsschwelle(beta, X, y, varargin)
%zeichneEntscheidungsschwelle(beta, X, y, [Grad, [xmin, xmax, ymin, ymax])
%zeichneEntscheidungsschwelle visualisiert die Entscheidungsschwelle
%der logistischen Regression f�r zwei Eingangsvariablen x1 und x2
%beta: Parametervektor
%X: Datenmatrix mit den Beobachtungen der Eingangsvariablen
%y: Vektor mit den Beobachtungen der Ausgangsvariable
%Grad: Maximaler Grad der Polynomargumente
%xmin bis xmax: horizontaler Bereich zur Auswertung der Entscheidungsschwelle
%ymin bis ymax: vertikaler   Bereich zur Auswertung der Entscheidungsschwelle

%Fall 1: Nur die Originalmerkmale x1 und x2 werden verwendet
if size(X, 2) <= 3
    % Definition der x-Achse
    plot_x = [min(X(:,2))-2,  max(X(:,2))+2];

    % Geradengleichung f�r die y-Koordinate
    plot_y = (-1./beta(3)).*(beta(2).*plot_x + beta(1));

    % Zeichnen der Entscheidungsschwelle
    plot(plot_x, plot_y, 'Linewidth',2)

%Fall 2: Auch abgeleitete Merkmale werden verwendet (Polynommerkmale)
else
    Largin = length(varargin);
    if Largin >=1
        Grad = varargin{1};
    else
        Grad = 2;
    end
    % Definition des Zeichenbereichs
    if Largin >=5
        xmin = varargin{2};
        xmax = varargin{3};
        ymin = varargin{4};
        ymax = varargin{5};
        u = linspace(xmin, xmax, 100);
        v = linspace(ymin, ymax, 100);        
    else
        u = linspace(0, 100, 100);
        v = linspace(0, 100, 100);
    end
    z = zeros(length(u), length(v));
    % Berechnung von z = X*beta im Zeichenbereich
    for i = 1:length(u)
        for j = 1:length(v)
            z(i,j) = PolynomMerkmale(u(i), v(j),Grad)*beta;
        end
    end
    z = z'; % Ergebnis muss transponiert werden, bevor wir contour aufrufen

    % Zeichnen der H�henlinie f�r z=0
    % Dazu m�ssen wir den Bereich [0, 0] (alle H�henlinien von 0 bis 0)
    % an den contour-Befehl weitergeben
    contour(u, v, z, [0, 0], 'LineWidth', 2)
end

end
